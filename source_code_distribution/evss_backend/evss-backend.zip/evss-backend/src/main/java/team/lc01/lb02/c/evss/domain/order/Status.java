package team.lc01.lb02.c.evss.domain.order;

public enum Status {
    Open, Closed
}
