package team.lc01.lb02.c.evss.util;

public class CODE {
    public static final int SUCCESS = 200;
    public static final int WRONG_INPUT = 400;
    public static final int REFUSE_COMMAND = 403;
    public static final int NOT_FOUND = 404;
    public static final int FAILURE = 500;

}
