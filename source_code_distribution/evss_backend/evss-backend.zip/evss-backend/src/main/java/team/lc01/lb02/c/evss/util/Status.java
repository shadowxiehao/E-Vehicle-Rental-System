package team.lc01.lb02.c.evss.util;

public class Status {
    public static final int UNDER_MAINTENANCE = -1;
    public static final int STANDBY = 0;
    public static final int IN_USE = 1;
    public static final int PARKING = 2;
    public static final int REPORTED = 3;
    public static final int DEFECTIVE = 4;

}
