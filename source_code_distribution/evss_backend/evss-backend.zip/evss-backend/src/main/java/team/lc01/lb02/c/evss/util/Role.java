package team.lc01.lb02.c.evss.util;


public enum Role {
    ADMIN, OPERATOR, USER
}