import React, { useState } from "react";

export const NotFound = () => {
    return (
        <div>
            <p>Not Found Page!</p>
        </div>
    )
}