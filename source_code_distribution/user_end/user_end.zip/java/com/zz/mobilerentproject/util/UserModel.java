package com.zz.mobilerentproject.util;

import java.io.Serializable;

public class UserModel implements Serializable {
    public String           user_id;
    public String           user_name;
    public String           user_email;
    public String           user_password;
}

